//
//  Helper.swift
//  SparkPerso
//
//  Created by Sébastien Hernoux on 17/10/2019.
//  Copyright © 2019 AlbanPerli. All rights reserved.
//

import UIKit

func delay(_ delay: Float, closure:@escaping ()->()) {
    let when = DispatchTime.now() + Double(delay)
    DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
}

extension UIViewController {
    func askForDurationAndSpeed(callback: @escaping(Float, Float)->()) {
        let ac = UIAlertController(title: "Fill values", message: nil, preferredStyle: .alert)
        ac.addTextField {(txt) in
            txt.placeholder = "Speed"
        }
        ac.addTextField {(txt) in
            txt.placeholder = "Duration"
        }

        let submitAction = UIAlertAction(title: "Add", style: .default) { [unowned ac] _ in
            if let speedText = ac.textFields![0].text,
               let durationText = ac.textFields![1].text,
               let speed = Float(speedText),
               let duration = Float(durationText) {
               callback(speed, duration)
            }
        }

        ac.addAction(submitAction)

        present(ac, animated: true)
    }
    
    func askForDurationAndSpeedAndHeading(callback: @escaping(Float, Float, Float)->()) {
        let ac = UIAlertController(title: "Fill values", message: nil, preferredStyle: .alert)
        ac.addTextField {(txt) in
            txt.placeholder = "Speed"
        }
        ac.addTextField {(txt) in
            txt.placeholder = "Duration"
        }
        
        ac.addTextField {(txt) in
            txt.placeholder = "Heading"
        }

        let submitAction = UIAlertAction(title: "Add", style: .default) { [unowned ac] _ in
            if let speedText = ac.textFields![0].text,
               let durationText = ac.textFields![1].text,
               let headingText = ac.textFields![2].text,
               let speed = Float(speedText),
               let duration = Float(durationText),
               let heading = Float(durationText) {
               callback(speed, duration, heading)
            }
        }

        ac.addAction(submitAction)

        present(ac, animated: true)
    }
}


